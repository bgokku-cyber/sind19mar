# Sind.19-Mar — Backend inicial

Primer entregable de código: esqueleto de API con NestJS y un endpoint de salud.

## Requisitos
- Node.js 20 o superior
- npm
- PostgreSQL (todavía no es necesario para probar `/health`)

## Ejecutar localmente o en un entorno cloud
1. Descomprime el proyecto.
2. Ejecuta `npm install`.
3. Ejecuta `npm run start:dev`.
4. Abre `http://localhost:3000/api/health`.

Respuesta esperada:
```json
{
  "status": "ok",
  "service": "sind19mar-api",
  "version": "0.1.0"
}
```

## Estado
- Incluido: estructura inicial NestJS y endpoint `/health`.
- Pendiente: conexión PostgreSQL/PostGIS, autenticación, roles, viajes, pagos, mapas y pruebas automatizadas.
- No se ha desplegado ni ejecutado este proyecto en un servidor.

## Identidad visual
Los colores verde oscuro, verde brillante y blanco se aplican a las interfaces móviles y web. Este backend no presenta interfaz gráfica.
